import java.util.Scanner;

/**
 Point de demarrage du programme
 */
public class Main {

    public static void main(String[] args) {
        // Course course = new Course();
       log.run();
    }


    }

