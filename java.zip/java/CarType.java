/**
 * ENUM les differents types de vehicules
*
 */

public enum CarType {
    VOITURE,
    MOTO,
   CAMION,

}
