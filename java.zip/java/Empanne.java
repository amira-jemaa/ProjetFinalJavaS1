
/**
 * L'interface Empanne
 */
public interface Empanne {
    public void collision (Course Course );
}
